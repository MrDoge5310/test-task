<?php
require_once 'ShipingCompany.php';

$company = $companys[$_GET['shiping_company']];
$weight = floatval($_GET['weight']);

$calc = new Calculator($company, $weight);
$result = $calc->calculate();

echo "<h2>Calculate results:</h2>";
echo "Company: " . $company->GetName() . "<br>";
echo "Total weight: " . $weight . " kg<br>";
echo "Shipping price: " . $result . " EUR";

echo '<select>';
foreach ($companys as $comp){
    echo '<option>' . $comp->GetName() . '</option>';
}
echo '</select>';