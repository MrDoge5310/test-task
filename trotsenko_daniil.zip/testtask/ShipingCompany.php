<?php

abstract class ShippingCompany
{
    private $name;

    function __construct($name)
    {
        $this->name = $name;
    }

    public function GetName() {
        return $this -> name;
    }


}

class NonStaticPriceComp extends ShippingCompany
{
    private $price;

    function __construct($name, $price){
        parent::__construct($name);
        $this->price = $price;
    }

    private function GetPrice() {
        return $this->price;
    }

    public function calculate_price($weight) : float {
        if ($weight > 0){
            return $this->price * floor($weight);
        }
        
    }
}

class StaticPriceComp extends ShippingCompany
{
    private $low_price;
    private $high_price;
    private $low_weight_limit;

    function __construct($name, $lprice, $hprice, $lw_limit){
        parent::__construct($name);
        $this->low_price = $lprice;
        $this->high_price = $hprice;
        $this->low_weight_limit = $lw_limit;
    }

    public function calculate_price($weight) : float {
        if ($weight > 0 and $weight <= $this->low_weight_limit){
            return $this->low_price;
        }
        else if ($weight > $this->low_weight_limit){
            return $this->high_price;
        }
       
    }
}

class Calculator{
    private $company;
    private $weight;

    function __construct($comp, $weight)
    {
        $this->company = $comp;
        $this->weight = $weight;
    }

    public function calculate() : float {
        return $this->company->calculate_price($this->weight);
    }
}

$companys = array(
    'TransCompany' => new NonStaticPriceComp('TransCompany', 1),
    'PackGroup' => new StaticPriceComp('PackGroup', 20, 100, 10)
);
